#Pluto: Motion Detection for Navigation in a VR Headset

###Description

The Pluto dataset was taken with a headset prototype, spanning 30 min in time,
  where 4 subjects, varying in age and gender were asked to explore
  virtual reality scene, while moving freely and naturally.
Recorded trajectories are rich with sporadic movements, side- and backward steps,
  participants lean and change direction and orientation restlessly.

3 subject trajectores are in `train` folder, one in `test`.
Each subject trajectores have corresponding input `inertial.csv` and ground truth `gt.csv` files


###Input format
First two columns describe event timestamps in seconds, former being the time of event
   and latter the events arrival time to the computer.
Both were preserved to model real system latency when needed. 3D accelerometer and gyroscope data follows.

```
timestamp arrival_timestamp ax ay az wx wy wz
0.001034 0.003761 0.344765 -9.576807 -0.679953 -0.054328 -0.018109 -0.025566
0.002874 0.003841 0.000000 0.000000 0.000000 -0.053263 -0.017044 -0.028762
0.004825 0.007047 -0.000416 -0.018828 0.045381 -0.056459 -0.023436 -0.028762
0.006776 0.010303 0.006061 0.006494 -0.026956 -0.058590 -0.023436 -0.027697
0.008732 0.010388 0.004529 0.069129 -0.027299 -0.059655 -0.014914 -0.031958
```

###Groud truth format
Ground truth file holds event times; Arrival timestamps are not repeated and filled in with invalid data (-1).
Third column is system status: 0 for stillness, 1 for motion.

```
timestamp arrival_timestamp xx
0.001034 -1.000000 0.000000
0.002874 -1.000000 0.000000
0.004825 -1.000000 0.000000
0.006776 -1.000000 0.000000
0.008732 -1.000000 0.000000
```

Another ground truth representation was also supplied:  `gt_md_start_trajectory.csv`, `gt_md_stop_trajectory.csv` files.
That file has a timestamp entry for every event (start or stop) happepening in trajectory.
```
timestamp arrival_timestamp
9.258333 -1.000000
11.466666 -1.000000
16.475000 -1.000000
18.025000 -1.000000
19.866666 -1.000000
20.183333 -1.000000
```

Please cite the article if the dataset is used in an academic work.
